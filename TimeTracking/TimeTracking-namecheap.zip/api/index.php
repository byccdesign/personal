<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function respond(int $status, array $body): void
{
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function sameOriginRequest(): bool
{
    if (empty($_SERVER['HTTP_ORIGIN'])) {
        return true;
    }

    $originHost = parse_url($_SERVER['HTTP_ORIGIN'], PHP_URL_HOST);
    $requestHost = preg_replace('/:\\d+$/', '', $_SERVER['HTTP_HOST'] ?? '');
    return is_string($originHost) && hash_equals(strtolower($requestHost), strtolower($originHost));
}

if (!sameOriginRequest()) {
    respond(403, ['error' => 'Cross-origin requests are not allowed.']);
}

$configFile = __DIR__ . '/config.php';
if (!is_file($configFile)) {
    respond(503, ['error' => 'Database configuration is missing. Copy config.example.php to config.php.']);
}

$config = require $configFile;
foreach (['host', 'database', 'username', 'password'] as $key) {
    if (!is_array($config) || !array_key_exists($key, $config)) {
        respond(500, ['error' => 'Database configuration is invalid.']);
    }
}

try {
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        $config['host'],
        (int) ($config['port'] ?? 3306),
        $config['database']
    );
    $pdo = new PDO($dsn, $config['username'], $config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (Throwable $error) {
    error_log('Time Tracker database connection failed: ' . $error->getMessage());
    respond(503, ['error' => 'The database is unavailable.']);
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

try {
    if ($method === 'GET') {
        $row = $pdo->query('SELECT payload, updated_at FROM time_tracker_state WHERE id = 1')->fetch();
        if (!$row) {
            respond(200, ['data' => null, 'updatedAt' => null]);
        }

        $payload = json_decode($row['payload'], true, 512, JSON_THROW_ON_ERROR);
        respond(200, ['data' => $payload, 'updatedAt' => $row['updated_at']]);
    }

    if ($method === 'PUT') {
        if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) {
            respond(415, ['error' => 'Content-Type must be application/json.']);
        }

        $contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
        if ($contentLength > 2 * 1024 * 1024) {
            respond(413, ['error' => 'The saved data exceeds the 2 MB limit.']);
        }

        $raw = file_get_contents('php://input');
        if ($raw === false || $raw === '') {
            respond(400, ['error' => 'A JSON request body is required.']);
        }

        $payload = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($payload) || !isset($payload['projects'], $payload['invoiceSettings']) ||
            !is_array($payload['projects']) || !is_array($payload['invoiceSettings'])) {
            respond(422, ['error' => 'The tracker data has an invalid structure.']);
        }

        $encoded = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        $statement = $pdo->prepare(
            'INSERT INTO time_tracker_state (id, payload) VALUES (1, :payload) '
            . 'ON DUPLICATE KEY UPDATE payload = VALUES(payload), updated_at = CURRENT_TIMESTAMP'
        );
        $statement->execute(['payload' => $encoded]);
        respond(200, ['saved' => true]);
    }

    header('Allow: GET, PUT');
    respond(405, ['error' => 'Method not allowed.']);
} catch (JsonException $error) {
    respond(400, ['error' => 'Invalid JSON data.']);
} catch (Throwable $error) {
    error_log('Time Tracker API failed: ' . $error->getMessage());
    respond(500, ['error' => 'The server could not process the request.']);
}
