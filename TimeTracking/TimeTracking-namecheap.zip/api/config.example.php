<?php
// Copy this file to config.php on the server and enter the values from cPanel.
return [
    'host' => 'localhost',
    'port' => 3306,
    'database' => 'CPANELUSER_timetracker',
    'username' => 'CPANELUSER_tracker',
    'password' => 'REPLACE_WITH_A_LONG_RANDOM_PASSWORD',
];
